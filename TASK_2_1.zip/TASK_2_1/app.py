from flask import Flask, render_template
from datetime import datetime
import pytz

app = Flask(__name__)

@app.route('/')
def index():
    # Get the current time in a specific timezone
    timezone = pytz.timezone('UTC')  # Change to your preferred timezone
    now = datetime.now(timezone)
    return render_template('index.html', current_time=now.strftime('%H:%M:%S'))

if __name__ == '__main__':
    app.run(debug=True)
