function updateClock() {
    fetch('/')
        .then(response => response.text())
        .then(html => {
            const clockElement = document.getElementById('clock');
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            clockElement.innerHTML = doc.getElementById('clock').innerHTML;
        });
}

// Update clock every second
setInterval(updateClock, 1000);

// Initial call to display clock immediately
updateClock();
