import os
import pandas as pd
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Get email credentials from environment variables
EMAIL_USER = os.getenv('EMAIL_USER')
EMAIL_PASS = os.getenv('EMAIL_PASS')

# Path to the CSV file
csv_path = r'C:\Users\chari\OneDrive\Documents\coders_cave\TASK_2_2\recipients.csv'

def send_email(to_email, subject, body):
    """Send an email to the specified recipient."""
    msg = MIMEMultipart()
    msg['From'] = EMAIL_USER
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(EMAIL_USER, EMAIL_PASS)
            server.send_message(msg)
        print(f"Email sent to {to_email}")
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication failed: {e}")
    except smtplib.SMTPConnectError as e:
        print(f"Connection failed: {e}")
    except Exception as e:
        print(f"Failed to send email to {to_email}: {e}")

def main():
    """Main function to read CSV and send emails."""
    try:
        df = pd.read_csv(csv_path)
        print("CSV file loaded successfully.")
    except FileNotFoundError:
        print(f"File not found: {csv_path}")
        return
    except pd.errors.EmptyDataError:
        print("CSV file is empty.")
        return
    except pd.errors.ParserError:
        print("Error parsing CSV file.")
        return

    print("Starting to send emails...")
    for index, row in df.iterrows():
        email = row.get('email', '').strip()  # Use .get() and strip() to avoid key errors and whitespace issues
        subject = row.get('subject', '').strip()
        body = row.get('body', '').strip()

        if email and subject and body:
            send_email(email, subject, body)
        else:
            print(f"Skipping row {index} due to missing data.")
            print(f"Row data: {row}")

if __name__ == "__main__":
    main()
